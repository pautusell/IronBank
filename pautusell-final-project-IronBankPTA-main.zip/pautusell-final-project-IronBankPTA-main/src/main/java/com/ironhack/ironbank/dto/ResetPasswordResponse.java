package com.ironhack.ironbank.dto;

import lombok.Data;

@Data
public class ResetPasswordResponse {
    private String message;
}
