package com.ironhack.ironbank.exception;

public class OperationalException extends RuntimeException{
    public OperationalException(String message){
        super(message);
    }
}
