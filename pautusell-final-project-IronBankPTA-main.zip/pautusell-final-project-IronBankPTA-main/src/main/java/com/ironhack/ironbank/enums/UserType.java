package com.ironhack.ironbank.enums;

public enum UserType {
    ACCOUNT_HOLDER, ADMIN
}
