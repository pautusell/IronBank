package com.ironhack.ironbank.enums;

public enum Status {
    FROZEN, ACTIVE
}
