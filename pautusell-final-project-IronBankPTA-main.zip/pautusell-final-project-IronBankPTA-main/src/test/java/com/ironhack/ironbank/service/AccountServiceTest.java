package com.ironhack.ironbank.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class AccountServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void checkBalance() {
    }

    @Test
    void getAccountStatement() {
    }

    @Test
    void createAccount() {
    }

    @Test
    void withdrawal() {
    }

    @Test
    void deposit() {
    }

    @Test
    void transfer() {
    }

    @Test
    void creditCardPurchase() {
    }

    @Test
    void creditCardWithdrawal() {
    }

    @Test
    void thirdPartyCharge() {
    }

    @Test
    void thirdPartyDeposit() {
    }

    @Test
    void editAccountConditions() {
    }

    @Test
    void editSecondaryOwner() {
    }

    @Test
    void editBalance() {
    }

    @Test
    void deleteAccount() {
    }

    @Test
    void getOverviewOfAccountsByType() {
    }
}