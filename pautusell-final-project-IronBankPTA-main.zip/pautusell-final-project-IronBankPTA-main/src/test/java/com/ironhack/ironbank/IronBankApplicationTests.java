package com.ironhack.ironbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IronBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
