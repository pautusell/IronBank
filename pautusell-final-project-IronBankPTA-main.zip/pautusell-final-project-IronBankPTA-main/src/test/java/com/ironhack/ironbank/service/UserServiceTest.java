package com.ironhack.ironbank.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class UserServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findAllUsers() {
    }

    @Test
    void findAllAccountHolders() {
    }

    @Test
    void newAccountHolder() {
    }

    @Test
    void newAdmin() {
    }

    @Test
    void resetPassword() {
    }

    @Test
    void updateAH() {
    }

    @Test
    void deleteUser() {
    }

    @Test
    void getAccountsByUserLogged() {
    }

    @Test
    void getAccountsByUserId() {
    }

    @Test
    void updateAccHolderMainAddress() {
    }

    @Test
    void updateAccHolderMailingAddress() {
    }
}