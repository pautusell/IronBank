package com.ironhack.ironbank.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@AutoConfigureMockMvc
class OperationControllerTest {

    @Test
    void checkBalance() {
    }

    @Test
    void getAccountStatement() {
    }

    @Test
    void withdrawal() {
    }

    @Test
    void deposit() {
    }

    @Test
    void testDeposit() {
    }

    @Test
    void creditCardWithdrawal() {
    }

    @Test
    void creditCardPurchase() {
    }
}