package com.ironhack.ironbank.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class TransactionServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getLastTransactions() {
    }

    @Test
    void findLastTransactionByType() {
    }

    @Test
    void findLastThreeUserTransactions() {
    }

    @Test
    void averageBalanceInPeriod() {
    }

    @Test
    void sumCashOutflowsInPeriod() {
    }

    @Test
    void sumCreditAmountsInPeriod() {
    }

    @Test
    void avgCashOutflowsInPeriod() {
    }

    @Test
    void getAccountTransactionsByPeriod() {
    }
}