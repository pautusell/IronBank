package com.ironhack.ironbank.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class ValidationServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void checkOwnerOrAdmin() {
    }

    @Test
    void checkBalanceConditions() {
    }

    @Test
    void applyPenaltyFee() {
    }

    @Test
    void checkAccountActive() {
    }

    @Test
    void checkEnoughBalance() {
    }

    @Test
    void checkSecretKey() {
    }

    @Test
    void checkCreditLimit() {
    }

    @Test
    void checkRegisteredTP() {
    }
}